/**
 * Aqui dentro probar el codigo que quieran
 */
function probarEjercicio(){
	alert("Esto funciona!");
}